const config = {
  title: 'BoredApe Dapp',
  description: 'A showcase dapp which is built for you to create your own',
  contractAddress: '0x22D832716D83f44179E6A82541f9Cf04D4BC2405',
  maxMintAmount: 4,
  presaleMaxMintAmount: 4,
  price: 0.049
}

export { config }
